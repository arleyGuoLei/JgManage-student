#include "stdafx.h"
#include "common.h"
CString common::user = "";

common::common()
{
}


common::~common()
{
}

CString common::getIniPath(CString fpName)
{
	TCHAR pFileName[MAX_PATH];TCHAR
	nPos = GetCurrentDirectory(MAX_PATH, pFileName);

	CString csFullPath(pFileName);
	if (nPos < 0)
		return CString("");
	else
		return csFullPath + "\\"+fpName+".ini";
}
