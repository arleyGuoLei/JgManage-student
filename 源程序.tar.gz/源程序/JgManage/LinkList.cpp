#include "stdafx.h"
#include "LinkList.h"
#include "common.h"
int LinkList::judgeNum = 50;
int LinkList::choiceNum = 50;

LinkList::LinkList()
{
	initAll();

	//�ֿ���ʼ�� �쳣
	//initChoose();
	//initJudge();
	TextAll.Judge = Judgehead;
	TextAll.choose = choosehead;
}


LinkList::~LinkList()
{
}


//д�����������ͻ��ڴ�й©  ����˵����CString�õĲ���һϵ�еġ��ĳ���һ������ initAll.
void LinkList::initJudge()
{
	LinkListJ L;
	L = (LinkListJ)malloc(sizeof(LNode));
	L->next = NULL;
	for (int i = 1; i <= judgeNum; i++)
	{
		LinkListJ p;
		p = (LinkListJ)malloc(sizeof(LNode));

		//CString t;
		//t.Format(_T("%d"), i);
		LPCTSTR t;
		t = (LPCTSTR)&i;

		//���ṹ�帳ֵ
		CString fp = common::getIniPath(CString("judge"));//��ȡuser.ini Path
		char questionIni[100];
		GetPrivateProfileString(t, TEXT("question"), "No question.", questionIni, 100, fp);
	
		strcpy_s(p->question, questionIni);
		//p->question = questionIni;
		p->answer = GetPrivateProfileInt(t, TEXT("answer"), 0, fp);
		p->next = L->next;
		L->next = p;
	}
	Judgehead = &L;
}
void LinkList::initChoose()
{
	LinkListC LC;
	cData cData;
	LC = (LinkListC)malloc(sizeof(CNode));
	LC->next = NULL;
	for (int i = 1; i <= choiceNum; i++)
	{
		LinkListC pC;
		pC = (LinkListC)malloc(sizeof(CNode));

		CString t;
		t.Format(_T("%d"), i);

		//���ṹ�帳ֵ
		CString fp = common::getIniPath(CString("choose"));//��ȡuser.ini Path
		char questionIni[100];
		GetPrivateProfileString(t, TEXT("question"), "No question.", questionIni, 100, fp);

		char optionAIni[50];
		char optionBIni[50];
		char optionCIni[50];
		char optionDIni[50];

		GetPrivateProfileString(t, TEXT("optionA"), "optionA.", optionAIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionB"), "optionB.", optionBIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionC"), "optionC.", optionCIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionD"), "optionD.", optionDIni, 50, fp);

		strcpy_s(cData.question, questionIni);
		strcpy_s(cData.optionA, optionAIni);
		strcpy_s(cData.optionB, optionBIni);
		strcpy_s(cData.optionC, optionCIni);
		strcpy_s(cData.optionD, optionDIni);

		cData.answer = GetPrivateProfileInt(t, TEXT("answer"), 0, fp);
		pC->data = cData;
		pC->next = LC->next;
		LC->next = pC;
	}
	choosehead = &LC;
}
//д�����������ͻ��ڴ�й©  ����˵����CString�õĲ���һϵ�еġ��ĳ���һ������ initAll.


void LinkList::initAll()
{
	LinkListJ L;
	L = (LinkListJ)malloc(sizeof(LNode));
	L->next = NULL;
	for (int i = 1; i <= judgeNum; i++)
	{
		LinkListJ p;
		p = (LinkListJ)malloc(sizeof(LNode));
		CString t;
		t.Format(_T("%d"), i);
		//���ṹ�帳ֵ
		CString fp = common::getIniPath(CString("judge"));//��ȡuser.ini Path
		char questionIni[100];
		GetPrivateProfileString(t, TEXT("question"), "No question.", questionIni, 100, fp);
		strcpy_s(p->question, questionIni);
		//p->question = questionIni;
		p->answer = GetPrivateProfileInt(t, TEXT("answer"), 0, fp);
		p->next = L->next;
		L->next = p;
	}
	Judgehead = &L;

	LinkListC LC;
	cData cData;
	LC = (LinkListC)malloc(sizeof(CNode));
	LC->next = NULL;
	for (int i = 1; i <= choiceNum; i++)
	{
		LinkListC pC;
		pC = (LinkListC)malloc(sizeof(CNode));

		CString t;
		t.Format(_T("%d"), i);

		//���ṹ�帳ֵ
		CString fp = common::getIniPath(CString("choose"));//��ȡuser.ini Path
		char questionIni[100];
		GetPrivateProfileString(t, TEXT("question"), "No question.", questionIni, 100, fp);

		char optionAIni[50];
		char optionBIni[50];
		char optionCIni[50];
		char optionDIni[50];

		GetPrivateProfileString(t, TEXT("optionA"), "optionA.", optionAIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionB"), "optionB.", optionBIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionC"), "optionC.", optionCIni, 50, fp);
		GetPrivateProfileString(t, TEXT("optionD"), "optionD.", optionDIni, 50, fp);

		strcpy_s(cData.question, questionIni);
		strcpy_s(cData.optionA, optionAIni);
		strcpy_s(cData.optionB, optionBIni);
		strcpy_s(cData.optionC, optionCIni);
		strcpy_s(cData.optionD, optionDIni);

		cData.answer = GetPrivateProfileInt(t, TEXT("answer"), 0, fp);
		pC->data = cData;
		pC->next = LC->next;
		LC->next = pC;
	}
	choosehead = &LC;
}
void LinkList::GetJudge(LinkListJ L, int i, LNode & e)
{

	LinkListJ p;
	int j = 1;
	p = L->next;
	while (p && j < i)
	{
		p = p->next;
		++j;
	}
	if (!p || j > i)
	{
		MessageBox(0, TEXT("Ԫ��λ�ó���������!"), TEXT("��ʾ:"), MB_OK);
	}
	e = *p;

}
void LinkList::GetChoose(LinkListC L, int i, CNode & e)
{
	LinkListC p;
	int j = 1;
	p = L->next;
	while (p && j < i)
	{
		p = p->next;
		++j;
	}
	if (!p || j > i)
	{
		MessageBox(0, TEXT("Ԫ��λ�ó���������!"), TEXT("��ʾ:"), MB_OK);
	}
	e = *p;

}
//MessageBox(0, TEXT("Ԫ��λ�ó���������!"), TEXT("��ʾ:"), MB_OK);


