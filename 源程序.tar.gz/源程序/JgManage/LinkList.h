#pragma once
#include<string>

class LinkList
{
public:
	LinkList();
	~LinkList();



	void initJudge();
	void initChoose();
	void initAll();


	static int judgeNum;
	static int choiceNum;

	typedef struct LNode
	{
		char question[100];
		int answer;
		struct LNode * next;
	}LNode, *LinkListJ;



	typedef struct cData
	{
		char question[100];
		char optionA[50];
		char optionB[50];
		char optionC[50];
		char optionD[50];
		int answer;
	};
	typedef struct CNode
	{
		cData data;
		struct CNode * next;
	}CNode, *LinkListC;

	LinkListJ * Judgehead;
	LinkListC *choosehead;

	typedef struct Text
	{
		LinkListJ * Judge;
		LinkListC *choose;
	};

	Text TextAll;

	void GetJudge(LinkListJ L, int i, LNode &e);
	void GetChoose(LinkListC L, int i, CNode &e);
	

};

