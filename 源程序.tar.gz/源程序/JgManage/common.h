#pragma once
class common
{
public:
	common();
	~common();
   static CString user;
   static CString getIniPath(CString);


};

